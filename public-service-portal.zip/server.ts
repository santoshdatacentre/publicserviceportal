import express from "express";
import path from "path";
import cors from "cors";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || "supersecretkey";

// Initialize Gemini API
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

app.use(cors());
app.use(express.json());

// In-memory mock database
const adminUser = {
  userId: "santoshdatacentre",
  passwordHash: bcrypt.hashSync("PSP@2030", 10),
  role: "admin",
};

let services = [
  { id: "1", title: "Aadhaar Services Info", description: "Learn how to update Aadhaar details.", icon: "IdCard", url: "https://myaadhaar.uidai.gov.in/" },
  { id: "2", title: "PAN Card Info", description: "Guide to apply for a new PAN card.", icon: "CreditCard", url: "https://www.pan.utiitsl.com/" },
  { id: "3", title: "Scholarship Info", description: "Find scholarships and application guidelines.", icon: "GraduationCap", url: "https://scholarships.gov.in/" },
  { id: "4", title: "Bihar Government", description: "Access all public services and portals of the Government of Bihar.", icon: "Building", url: "https://state.bihar.gov.in/" },
  { id: "5", title: "National Government", description: "Access National Portal of India for all central government services.", icon: "Landmark", url: "https://www.india.gov.in/" },
  { id: "6", title: "RTPS Bihar (ServicePlus)", description: "Apply for Caste, Income, Domicile and other certificates.", icon: "FileText", url: "https://serviceonline.bihar.gov.in/" },
  { id: "7", title: "Bihar Bhumi", description: "Access Bihar land records, Khata, and Jamabandi details.", icon: "MapPin", url: "https://biharbhumi.bihar.gov.in/" },
  { id: "8", title: "Sahyog Bihar", description: "Public grievance portal of Bihar Government (Sahyog).", icon: "Landmark", url: "https://sahyog.bihar.gov.in/" },
  { id: "9", title: "EPDS Bihar (Ration Card)", description: "Food & Consumer Protection Department. Ration card details and management.", icon: "IdCard", url: "https://epds.bihar.gov.in/" },
  { id: "10", title: "e-Labharthi Bihar", description: "Pension, scholarships scheme payments and status details.", icon: "CreditCard", url: "https://elabharthi.bih.nic.in/" },
  { id: "11", title: "Lok Shikayat Bihar", description: "Bihar Right to Public Grievance Redressal system.", icon: "FileText", url: "https://lokshikayat.bihar.gov.in/" },
  { id: "12", title: "Parimarjan Bihar", description: "Correction in land records like Jamabandi, area, name etc.", icon: "MapPin", url: "https://parimarjan.bihar.gov.in/" },
  { id: "13", title: "RTI Online Bihar", description: "Submit applications under Right to Information (RTI).", icon: "FileText", url: "https://rtionline.bihar.gov.in/" },
  { id: "14", title: "7 Nishchay Yuva Up Mission", description: "Various schemes for youth empowerment in Bihar.", icon: "Briefcase", url: "https://www.7nishchay-yuvaupmission.bihar.gov.in/" },
  { id: "15", title: "RTPS Bihar (Legacy)", description: "Legacy view of Right to Public Services portal of Bihar.", icon: "Building", url: "https://rtps.bihar.gov.in/rtps/Home.aspx" }
];

let aiTools = [
  { id: "1", title: "AI Prompt Generator", description: "Generate highly effective prompts.", enabled: true },
  { id: "2", title: "Resume Builder AI", description: "Create professional resumes quickly.", enabled: true },
  { id: "3", title: "Shadi Bio Data Generator", description: "Generate matrimonial bio data formats and prompts using AI.", enabled: true },
  { id: "4", title: "Invitation Card Generator", description: "Create customized invitation card messages for weddings and events.", enabled: true },
];

let websiteContent = {
  heroTitle: "All Government Services + AI Tools + Chatbot in One Secure Platform",
  heroSubtitle: "Easy access to digital services for all users",
};

// --- Middleware ---
function authenticateToken(req: any, res: any, next: any) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (token == null) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    if (user.role !== 'admin') return res.sendStatus(403);
    next();
  });
}

// --- API Routes ---

// Auth
app.post("/api/auth/login", (req, res) => {
  const { userId, password } = req.body;
  if (userId === adminUser.userId && bcrypt.compareSync(password, adminUser.passwordHash)) {
    const token = jwt.sign({ userId: adminUser.userId, role: adminUser.role }, JWT_SECRET, { expiresIn: '8h' });
    res.json({ token, user: { userId: adminUser.userId, role: adminUser.role } });
  } else {
    res.status(401).json({ error: "Invalid credentials" });
  }
});

// Public Data
app.get("/api/data", (req, res) => {
  res.json({
    services,
    aiTools: aiTools.filter(t => t.enabled),
    websiteContent
  });
});

// Admin Data Routes
app.get("/api/admin/services", authenticateToken, (req, res) => {
  res.json(services);
});
app.post("/api/admin/services", authenticateToken, (req, res) => {
  const newService = { id: Date.now().toString(), ...req.body };
  services.push(newService);
  res.json(newService);
});
app.put("/api/admin/services/:id", authenticateToken, (req, res) => {
  services = services.map(s => s.id === req.params.id ? { ...s, ...req.body } : s);
  res.json({ success: true });
});
app.delete("/api/admin/services/:id", authenticateToken, (req, res) => {
  services = services.filter(s => s.id !== req.params.id);
  res.json({ success: true });
});

app.get("/api/admin/tools", authenticateToken, (req, res) => {
  res.json(aiTools);
});
app.put("/api/admin/tools/:id", authenticateToken, (req, res) => {
  aiTools = aiTools.map(t => t.id === req.params.id ? { ...t, ...req.body } : t);
  res.json({ success: true });
});

app.put("/api/admin/content", authenticateToken, (req, res) => {
  websiteContent = { ...websiteContent, ...req.body };
  res.json(websiteContent);
});

// Gemini AI Chatbot / Tools Endpoint
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { messages } = req.body;
    
    // Add system persona
    const systemInstruction = "You are 'AI Assistant - Public Service Bot'. Your goal is to help users with government services, document creation, AI tools, and general FAQs. Reply cleanly and be helpful. Support both English and Hindi.";
    
    // Construct prompt string from messages array
    const prompt = messages.map((m: any) => `${m.role === 'user' ? 'User' : 'Bot'}: ${m.content}`).join('\n') + `\nBot:`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: systemInstruction + "\n\n" + prompt,
    });
    
    res.json({ reply: response.text });
  } catch (err: any) {
    console.error("Gemini API Error:", err);
    res.status(500).json({ error: "Failed to generate AI response." });
  }
});

app.post("/api/ai/tool", async (req, res) => {
  try {
    const { toolName, input } = req.body;
    
    const prompt = `You are an AI tool inside a Public Services Portal. Tool Name: ${toolName}. User Input: ${input}. Provide the generated result clearly without any introductory conversational text.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    res.json({ result: response.text });
  } catch (err: any) {
    res.status(500).json({ error: "Failed to execute AI tool." });
  }
});

// --- Boot Server ---
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
