import { Navigate, Outlet } from 'react-router-dom';
import { useAuthStore } from '../store';

export function ProtectedRoute() {
  const { token, user } = useAuthStore();

  if (!token || user?.role !== 'admin') {
    return <Navigate to="/login" replace />;
  }

  return <Outlet />;
}
