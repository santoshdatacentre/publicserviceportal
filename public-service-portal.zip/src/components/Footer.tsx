import { Link } from "react-router-dom";
import { Landmark, Twitter, Facebook, Instagram, Github } from "lucide-react";

export function Footer() {
  return (
    <footer className="h-12 md:h-16 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 px-4 md:px-8 flex flex-col md:flex-row items-center justify-center md:justify-between shrink-0 gap-2 md:gap-0">
      <p className="text-[11px] text-slate-500 dark:text-slate-400">&copy; {new Date().getFullYear()} Public Service Portal India. Secure Govt Access Portal.</p>
      <div className="flex gap-6">
        <Link to="/about" className="text-[11px] font-bold text-slate-400 hover:text-blue-600 dark:hover:text-blue-400">About Us</Link>
        <Link to="/privacy" className="text-[11px] font-bold text-slate-400 hover:text-blue-600 dark:hover:text-blue-400">Privacy Policy</Link>
        <Link to="/contact" className="text-[11px] font-bold text-slate-400 hover:text-blue-600 dark:hover:text-blue-400">Contact Support</Link>
      </div>
    </footer>
  );
}
