import { IdCard, CreditCard, GraduationCap, Train, FileText, Image, Briefcase, Calendar, MapPin, Sparkles, Building, Settings, FileIcon, Info, Landmark, Globe } from 'lucide-react';

export const IconMap: Record<string, React.ElementType> = {
  IdCard,
  CreditCard,
  GraduationCap,
  Train,
  FileText,
  Image,
  Briefcase,
  Calendar,
  MapPin,
  Sparkles,
  Building,
  Settings,
  FileIcon,
  Info,
  Landmark,
  Globe
};

interface IconProps {
  name: string;
  className?: string;
}

export function DynamicIcon({ name, className }: IconProps) {
  const IconComponent = IconMap[name] || Sparkles;
  return <IconComponent className={className} />;
}
