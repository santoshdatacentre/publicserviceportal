import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, Loader2, Copy, CheckCircle2 } from 'lucide-react';
import { cn } from '../lib/utils';

export function AITools() {
  const [tools, setTools] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTool, setActiveTool] = useState<any>(null);
  
  // Tool execution state
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');
  const [executing, setExecuting] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetch('/api/data')
      .then(res => res.json())
      .then(data => {
        setTools(data.aiTools || []);
        if (data.aiTools && data.aiTools.length > 0) {
          setActiveTool(data.aiTools[0]);
        }
        setLoading(false);
      });
  }, []);

  const handleGenerate = async () => {
    if (!input.trim() || !activeTool) return;
    setExecuting(true);
    setResult('');
    setCopied(false);
    
    try {
      const res = await fetch('/api/ai/tool', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ toolName: activeTool.title, input })
      });
      const data = await res.json();
      setResult(data.result || 'Failed to generate content.');
    } catch (e) {
      setResult('An error occurred. Please try again.');
    } finally {
      setExecuting(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="mb-12">
          <motion.h1 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-3xl md:text-4xl font-extrabold text-slate-900 dark:text-white flex items-center gap-3"
          >
            <Bot className="h-10 w-10 text-indigo-600" />
            AI Smart Tools
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mt-4 text-lg text-slate-600 dark:text-slate-400 max-w-2xl"
          >
            Leverage artificial intelligence to generate documents, resumes, prompts and formats instantly.
          </motion.p>
        </div>

        {loading ? (
           <div className="flex justify-center py-20"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div></div>
        ) : (
          <div className="flex flex-col md:flex-row gap-8">
            
            {/* Sidebar Tools List */}
            <div className="w-full md:w-80 flex-none space-y-2">
              {tools.map(tool => (
                <button
                  key={tool.id}
                  onClick={() => { setActiveTool(tool); setResult(''); setInput(''); }}
                  className={cn(
                    "w-full text-left p-4 rounded-xl transition-all border outline-none",
                    activeTool?.id === tool.id 
                      ? "bg-white dark:bg-slate-900 border-indigo-600 dark:border-indigo-500 shadow-sm ring-1 ring-indigo-600/20" 
                      : "bg-transparent border-transparent hover:bg-slate-100 dark:hover:bg-slate-900/50 text-slate-600 dark:text-slate-400"
                  )}
                >
                  <h3 className={cn("font-semibold", activeTool?.id === tool.id ? "text-indigo-700 dark:text-indigo-400" : "text-slate-700 dark:text-slate-300")}>{tool.title}</h3>
                  <p className="text-xs mt-1 opacity-80 line-clamp-2">{tool.description}</p>
                </button>
              ))}
            </div>

            {/* Active Tool Area */}
            <div className="flex-1">
              <AnimatePresence mode="wait">
                {activeTool && (
                  <motion.div
                    key={activeTool.id}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="bg-white dark:bg-slate-900 rounded-3xl p-6 md:p-10 border border-slate-200 dark:border-slate-800 shadow-sm"
                  >
                    <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">{activeTool.title}</h2>
                    <p className="text-slate-600 dark:text-slate-400 mb-8">{activeTool.description}</p>
                    
                    <div className="space-y-6">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                          Input Details
                        </label>
                        <textarea
                          rows={4}
                          value={input}
                          onChange={(e) => setInput(e.target.value)}
                          placeholder="E.g. I need a resume for a Software Engineer role with 3 years of experience..."
                          className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white"
                        />
                      </div>
                      
                      <button
                        onClick={handleGenerate}
                        disabled={executing || !input.trim()}
                        className="w-full flex items-center justify-center px-6 py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl font-medium transition-colors"
                      >
                        {executing ? (
                          <><Loader2 className="animate-spin -ml-1 mr-2 h-5 w-5" /> Generating...</>
                        ) : (
                          'Generate Now'
                        )}
                      </button>

                      {/* Result Box */}
                      {result && (
                        <motion.div 
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          className="mt-8"
                        >
                          <div className="flex items-center justify-between mb-2">
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                              Result
                            </label>
                            <button 
                              onClick={handleCopy}
                              className="text-xs flex items-center gap-1 text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300"
                            >
                              {copied ? <CheckCircle2 className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                              {copied ? 'Copied' : 'Copy Output'}
                            </button>
                          </div>
                          <div className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 p-4 text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap">
                            {result}
                          </div>
                        </motion.div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            
          </div>
        )}
      </div>
    </div>
  );
}
