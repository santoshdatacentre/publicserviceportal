import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowRight, Bot, ShieldCheck, Zap } from 'lucide-react';
import { DynamicIcon } from '../components/DynamicIcon';
import { useEffect, useState } from 'react';

export function Home() {
  const [data, setData] = useState<{ services: any[], aiTools: any[], websiteContent: any } | null>(null);

  useEffect(() => {
    fetch('/api/data')
      .then(res => res.json())
      .then(setData);
  }, []);

  if (!data) return <div className="min-h-screen flex items-center justify-center dark:bg-slate-900"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div></div>;

  return (
    <div className="bg-slate-50 dark:bg-slate-950 min-h-screen">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 h-auto pb-16">
        <div className="w-full min-h-[300px] sm:h-auto rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden relative flex flex-col sm:flex-row">
          <div className="flex-1 p-8 md:p-12 flex flex-col justify-center relative z-10">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-3xl md:text-5xl font-extrabold text-slate-900 dark:text-white mb-4 tracking-tight"
            >
              {data.websiteContent?.heroTitle || 'All Government Services + AI Tools + Chatbot in One Secure Platform'}
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-lg md:text-xl text-slate-600 dark:text-slate-400 max-w-2xl"
            >
              {data.websiteContent?.heroSubtitle || 'Easy access to digital services for all users'}
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="flex flex-wrap gap-4 mt-8"
            >
              <Link to="/services" className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-md shadow-blue-200 dark:shadow-blue-900/20 transition-all flex items-center">
                Explore Services
              </Link>
              <Link to="/ai-tools" className="px-6 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl font-bold border border-slate-200 dark:border-slate-700 transition-all flex items-center">
                Use AI Tools
              </Link>
            </motion.div>
          </div>
          <div className="hidden md:flex w-1/3 bg-gradient-to-l from-blue-50 dark:from-blue-900/10 to-transparent items-center justify-center p-8 z-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 w-full">
              <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
                <p className="text-xs text-slate-400 font-bold uppercase">Total Services</p>
                <p className="text-2xl font-black text-blue-600 dark:text-blue-400">450+</p>
              </div>
              <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
                <p className="text-xs text-slate-400 font-bold uppercase">Live Users</p>
                <p className="text-2xl font-black text-orange-500">12.4k</p>
              </div>
            </div>
          </div>
          <div className="absolute -right-16 -top-16 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute left-[20%] bottom-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-slate-50 dark:bg-slate-950 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Why Choose Our Portal</h2>
            <p className="mt-4 text-slate-600 dark:text-slate-400">Everything you need in one secure place.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-2xl flex items-center justify-center mb-6 text-blue-600 dark:text-blue-400">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-3">Secure Access</h3>
              <p className="text-slate-600 dark:text-slate-400">Admin-controlled verified services ensuring you interact only with genuine portals.</p>
            </div>
            
            <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-2xl flex items-center justify-center mb-6 text-purple-600 dark:text-purple-400">
                <Bot className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-3">AI Powered Assistant</h3>
              <p className="text-slate-600 dark:text-slate-400">24/7 smart assistant available to answer queries in English and Hindi.</p>
            </div>
            
            <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/30 rounded-2xl flex items-center justify-center mb-6 text-orange-600 dark:text-orange-400">
                <Zap className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-3">Instant Tools</h3>
              <p className="text-slate-600 dark:text-slate-400">Access quick utilities like PDF editors, image tools, and AI generation directly in browser.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Trending Services and AI Tools Wrapper */}
      <section className="py-24 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Services Column */}
            <div className="lg:col-span-2">
              <div className="flex justify-between items-end mb-6">
                <h2 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Trending Govt Services</h2>
                <Link to="/services" className="text-indigo-600 dark:text-indigo-400 text-sm font-medium hover:underline items-center flex">
                  View all <ArrowRight className="ml-1 h-3 w-3" />
                </Link>
              </div>
              
              <div className="grid sm:grid-cols-2 gap-4">
                {data.services?.slice(0, 4).map((service, i) => {
                   const colors = [
                     { bg: 'bg-blue-50 dark:bg-blue-900/30', text: 'text-blue-600 dark:text-blue-400', border: 'hover:border-blue-300 dark:hover:border-blue-700' },
                     { bg: 'bg-orange-50 dark:bg-orange-900/30', text: 'text-orange-600 dark:text-orange-400', border: 'hover:border-orange-300 dark:hover:border-orange-700' },
                     { bg: 'bg-purple-50 dark:bg-purple-900/30', text: 'text-purple-600 dark:text-purple-400', border: 'hover:border-purple-300 dark:hover:border-purple-700' },
                     { bg: 'bg-green-50 dark:bg-green-900/30', text: 'text-green-600 dark:text-green-400', border: 'hover:border-green-300 dark:hover:border-green-700' },
                   ];
                   const color = colors[i % colors.length];
                   return (
                     <motion.div 
                       key={service.id}
                       initial={{ opacity: 0, y: 20 }}
                       whileInView={{ opacity: 1, y: 0 }}
                       viewport={{ once: true }}
                       transition={{ delay: i * 0.1 }}
                       onClick={() => { if (service.url) window.open(service.url, '_blank'); }}
                       className={`group block p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 ${color.border} shadow-sm transition-all cursor-pointer`}
                     >
                       <div className={`w-10 h-10 rounded-lg ${color.bg} ${color.text} flex items-center justify-center mb-4`}>
                         <DynamicIcon name={service.icon} className="h-6 w-6" />
                       </div>
                       <h3 className="font-bold text-slate-800 dark:text-white mb-1">{service.title}</h3>
                       <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">{service.description}</p>
                     </motion.div>
                   );
                })}
              </div>
            </div>

            {/* AI Tools Column */}
            <div className="lg:col-span-1">
              <h2 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6">Smart AI Tools</h2>
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm p-5 space-y-4">
                {data.aiTools?.slice(0, 3).map((tool, i) => {
                  const gradientColors = [
                    'from-purple-600 to-blue-500',
                    'from-orange-500 to-red-500',
                    'from-blue-500 to-teal-400'
                  ];
                  const grad = gradientColors[i % gradientColors.length];
                  return (
                    <div key={tool.id} className="flex items-center gap-4 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer" onClick={() => window.location.href = '/ai-tools' }>
                      <div className={`w-10 h-10 bg-gradient-to-br ${grad} rounded-lg flex items-center justify-center shrink-0`}>
                        <Bot className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-bold text-slate-800 dark:text-white">{tool.title}</p>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">{tool.description}</p>
                      </div>
                    </div>
                  );
                })}
                <div className="pt-2">
                  <Link to="/ai-tools" className="block w-full py-2 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl text-slate-400 dark:text-slate-500 text-xs font-bold hover:bg-slate-50 dark:hover:bg-slate-800/50 text-center transition-colors">
                    Explore All AI Tools
                  </Link>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>
    </div>
  );
}
