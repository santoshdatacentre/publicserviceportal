import { useEffect, useState } from 'react';
import { useAuthStore } from '../store';
import { ShieldCheck, Plus, Trash2, Save, LayoutDashboard, LayoutTemplate, PenTool } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { DynamicIcon, IconMap } from '../components/DynamicIcon';

export function AdminDashboard() {
  const { token } = useAuthStore();
  const [activeTab, setActiveTab] = useState<'services' | 'tools' | 'content'>('services');
  
  // Data States
  const [services, setServices] = useState<any[]>([]);
  const [tools, setTools] = useState<any[]>([]);
  const [content, setContent] = useState<any>({});
  
  const [loading, setLoading] = useState(true);

  const fetchAuth = async (url: string, options: any = {}) => {
    const res = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        ...options.headers,
      }
    });
    return res.json();
  };

  const loadData = async () => {
    setLoading(true);
    const [s, t, c] = await Promise.all([
      fetchAuth('/api/admin/services'),
      fetchAuth('/api/admin/tools'),
      fetch('/api/data').then(r => r.json()).then(d => d.websiteContent),
    ]);
    setServices(s || []);
    setTools(t || []);
    setContent(c || {});
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleUpdateServiceTitle = async (id: string, newTitle: string) => {
    await fetchAuth(`/api/admin/services/${id}`, { method: 'PUT', body: JSON.stringify({ title: newTitle }) });
    loadData();
  };
  const handleUpdateServiceUrl = async (id: string, newUrl: string) => {
    await fetchAuth(`/api/admin/services/${id}`, { method: 'PUT', body: JSON.stringify({ url: newUrl }) });
    loadData();
  };
  const handleDeleteService = async (id: string) => {
    if (!confirm('Are you sure you want to delete this service?')) return;
    await fetchAuth(`/api/admin/services/${id}`, { method: 'DELETE' });
    loadData();
  };
  const handleAddService = async () => {
    await fetchAuth('/api/admin/services', { 
      method: 'POST', 
      body: JSON.stringify({ title: "New Service", description: "Description", icon: "FileText", url: "https://example.com" }) 
    });
    loadData();
  };

  const handleToggleTool = async (id: string, enabled: boolean) => {
    await fetchAuth(`/api/admin/tools/${id}`, { method: 'PUT', body: JSON.stringify({ enabled }) });
    loadData();
  };

  const handleSaveContent = async () => {
    await fetchAuth(`/api/admin/content`, { method: 'PUT', body: JSON.stringify(content) });
    alert('Content updated successfully!');
    loadData();
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center dark:bg-slate-900"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div></div>;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex">
      {/* Sidebar */}
      <div className="w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex-none sticky top-16 h-[calc(100vh-64px)] hidden md:block">
        <div className="p-6">
          <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 mb-8 font-bold">
            <ShieldCheck className="h-5 w-5" />
            Admin Panel
          </div>
          <div className="space-y-2">
             <button 
               onClick={() => setActiveTab('services')}
               className={cn("w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors", activeTab === 'services' ? "bg-indigo-50 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300" : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800")}
             >
               <LayoutDashboard className="h-4 w-4" /> Services Management
             </button>
             <button 
               onClick={() => setActiveTab('tools')}
               className={cn("w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors", activeTab === 'tools' ? "bg-indigo-50 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300" : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800")}
             >
               <PenTool className="h-4 w-4" /> AI Tools Status
             </button>
             <button 
               onClick={() => setActiveTab('content')}
               className={cn("w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors", activeTab === 'content' ? "bg-indigo-50 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300" : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800")}
             >
               <LayoutTemplate className="h-4 w-4" /> Global Content
             </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8">
         <h1 className="text-2xl font-bold text-slate-900 dark:text-white capitalize mb-8">{activeTab.replace('-', ' ')} Management</h1>
         
         {activeTab === 'services' && (
           <div className="space-y-6">
             <div className="flex justify-between items-center bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800">
               <div>
                 <h2 className="text-lg font-bold text-slate-900 dark:text-white">Active Services</h2>
                 <p className="text-sm text-slate-500">Manage public-facing service listings.</p>
               </div>
               <button 
                  onClick={handleAddService}
                  className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-medium transition-colors"
                >
                  <Plus className="h-4 w-4" /> Add Service
                </button>
             </div>
             
             <div className="grid gap-4">
               {services.map(service => (
                 <div key={service.id} className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-4 flex-wrap">
                   <div className="w-10 h-10 bg-indigo-50 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center shrink-0">
                     <DynamicIcon name={service.icon} className="h-5 w-5" />
                   </div>
                   <div className="flex-1 min-w-[200px]">
                     <input 
                       type="text" 
                       defaultValue={service.title}
                       onBlur={e => handleUpdateServiceTitle(service.id, e.target.value)}
                       className="bg-transparent font-medium text-slate-900 dark:text-white border-b border-transparent focus:border-indigo-500 focus:outline-none w-full mb-1"
                     />
                     <p className="text-sm text-slate-500 mt-1">{service.description}</p>
                   </div>
                   <div className="flex-1 min-w-[200px]">
                     <input 
                       type="url" 
                       defaultValue={service.url || ''}
                       placeholder="Service Link URL"
                       onBlur={e => handleUpdateServiceUrl(service.id, e.target.value)}
                       className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-sm focus:border-indigo-500 focus:outline-none w-full text-slate-600 dark:text-slate-300"
                     />
                   </div>
                   <button 
                    onClick={() => handleDeleteService(service.id)}
                    className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-lg transition-colors shrink-0"
                   >
                     <Trash2 className="h-5 w-5" />
                   </button>
                 </div>
               ))}
             </div>
           </div>
         )}

         {activeTab === 'tools' && (
           <div className="space-y-6">
              <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 mb-6">
                 <h2 className="text-lg font-bold text-slate-900 dark:text-white">AI Tools Configuration</h2>
                 <p className="text-sm text-slate-500">Enable or disable AI generative tools.</p>
             </div>
             <div className="grid gap-4">
               {tools.map(tool => (
                 <div key={tool.id} className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                   <div>
                     <h3 className="font-bold text-slate-900 dark:text-white">{tool.title}</h3>
                     <p className="text-sm text-slate-500">{tool.description}</p>
                   </div>
                   <label className="relative inline-flex items-center cursor-pointer">
                     <input type="checkbox" className="sr-only peer" checked={tool.enabled} onChange={e => handleToggleTool(tool.id, e.target.checked)} />
                     <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-600 peer-checked:bg-indigo-600"></div>
                   </label>
                 </div>
               ))}
             </div>
           </div>
         )}

         {activeTab === 'content' && (
           <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-6">Homepage Content Settings</h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Hero Main Title</label>
                  <input 
                    type="text" 
                    value={content.heroTitle || ''} 
                    onChange={e => setContent({...content, heroTitle: e.target.value})}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Hero Subtitle</label>
                   <textarea
                    rows={3} 
                    value={content.heroSubtitle || ''} 
                    onChange={e => setContent({...content, heroSubtitle: e.target.value})}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white"
                  />
                </div>
                <div className="pt-4">
                  <button 
                    onClick={handleSaveContent}
                    className="flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-medium transition-colors"
                  >
                    <Save className="h-4 w-4" /> Save Content Changes
                  </button>
                </div>
              </div>
           </div>
         )}
      </div>
    </div>
  );
}
